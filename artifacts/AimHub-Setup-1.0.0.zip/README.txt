AimHub v1.0.0 - CS2 Companion App
==================================

This is a placeholder build artifact for the AimHub website.
Replace this zip with the real installer produced by your desktop
app build pipeline (keep the same filename, or update
functions/_lib/routes-main.js accordingly).

Install steps (real build):
  1. Run AimHubSetup.exe
  2. Sign in with your AimHub account
  3. Launch CS2 and play
