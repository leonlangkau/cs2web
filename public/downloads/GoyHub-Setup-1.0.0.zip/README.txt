GoyHub v1.0.0 — CS2 Companion App
==================================

This is a placeholder build artifact for the GoyHub website.
Replace this zip with the real installer produced by your desktop
app build pipeline (keep the same filename, or update
src/routes/main.js accordingly).

Install steps (real build):
  1. Run GoyHubSetup.exe
  2. Sign in with your GoyHub account
  3. Launch CS2 and play

https://goyhub.local
